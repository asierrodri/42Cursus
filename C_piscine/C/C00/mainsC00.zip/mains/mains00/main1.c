void	ft_print_alphabet();

int main (void)
{
	ft_print_alphabet();
	return(0);
}
