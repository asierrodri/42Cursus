

void ft_is_negative(int n);


int main (void)
{
	ft_is_negative(-5);
	ft_is_negative(6);
	ft_is_negative(0);
}

